package com.epnfis.contactosapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class EliminarContactoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_eliminar_contacto)
    }
}
