package com.epnfis.contactosapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class IngresarContactoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ingresar_contacto)
    }
}
