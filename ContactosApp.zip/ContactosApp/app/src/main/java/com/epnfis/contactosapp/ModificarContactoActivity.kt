package com.epnfis.contactosapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ModificarContactoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_modificar_contacto)
    }
}
